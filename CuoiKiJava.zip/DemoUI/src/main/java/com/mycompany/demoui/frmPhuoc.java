
package com.mycompany.demoui;


import java.awt.Graphics;
import java.awt.Image;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.util.*;
import java.io.*;
import java.time.LocalDateTime;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.RowFilter;
import javax.swing.plaf.basic.BasicInternalFrameUI;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
public class frmPhuoc extends javax.swing.JFrame {
    public frmPhuoc() {
        
    ImageIcon imageIcon = new ImageIcon("C:\\Users\\THINKPAD\\Downloads\\siu.jfif");
    Image image = imageIcon.getImage();
    
    int imageWidth = image.getWidth(null);
    int imageHeight = image.getHeight(null);
    int frameWidth = 718;
    int frameHeight = 477;
    image = image.getScaledInstance(frameWidth, frameHeight, Image.SCALE_SMOOTH);
    JLabel backgroundLabel = new JLabel(new ImageIcon(image));
    setContentPane(backgroundLabel);
    initComponents();
    dlogDoiMK.setLocationRelativeTo(null);
    dlogDoiMK.setSize(402,278);
    person = new HashSet<>();
    setSize(718,477);
    banHashSet = new HashSet<>();
    phanquyen = new HashMap<>();
           stBan1 = new HashMap<>();
                    String fileName  = "nhanvien.bin";
                    String fileDonHang = "donhang.bin";
                    String fileBan = "ban.bin";
                    File nhanvienFile = new File(fileName);
                    File donhangFile = new File(fileDonHang);
                    File banFile = new File(fileBan);
                    

                    try{
                        if(!nhanvienFile.exists()){
                            nhanvienFile.createNewFile();
                        }
                        if(!donhangFile.exists()){
                            donhangFile.createNewFile();
                        }
                         if(!banFile.exists()){
                            banFile.createNewFile();
                        }
                        DataInputStream myNhanVien = new DataInputStream(new FileInputStream(nhanvienFile));
                       while(myNhanVien.available()>0){
                           
                           int id = myNhanVien.readInt();
                           person.add(id);
                           
                           String ten = myNhanVien.readUTF();
                           int tuoi = myNhanVien.readInt();
                           String que = myNhanVien.readUTF();
                           float luong = myNhanVien.readFloat();
                           String chucvu = myNhanVien.readUTF();
                           Object[] newRow = {id,ten,tuoi,que,luong,chucvu};
                           if(!"Nhân Viên".equals(chucvu)){
                               phanquyen.put(id, 1);
                           }
                           else{
                                phanquyen.put(id, 0);
                           }
                           model_nhanvien.addRow(newRow);
                       }
                       DataInputStream myDonHang = new DataInputStream(new FileInputStream(donhangFile));
                       while(myDonHang.available()>0){
                           int ma= myDonHang.readInt();
                           int BanId= myDonHang.readInt();
                           String ten_mon = myDonHang.readUTF();

                          
                           float don_gia =  myDonHang.readFloat();
                           int  soluong = myDonHang.readInt();
                           String status = myDonHang.readUTF();
                           String time = myDonHang.readUTF();
                           Object[] newRow = {ma,BanId,ten_mon,don_gia,soluong,status,time};
                           model_don_hang.addRow(newRow);
                       }
                       DataInputStream myBan = new DataInputStream(new FileInputStream(banFile));
                       while(myBan.available()>0){
                           int ma= myBan.readInt();
                           banHashSet.add(ma);
                           String loai = myBan.readUTF();

                          
                          
                           String status = myBan.readUTF();
                           if("Mới".equals(status)){
                               stBan1.put(ma,1);
                           }
                    }
                           else{
                                stBan1.put(ma,0);
                           }
                                  
                           Object[] newRow = {ma,loai,status};
                           model_ban.addRow(newRow);
                       }

                    }
                    catch(IOException e){
                        System.out.println("Loi: "+e);
                    }
                    jTable1.setModel(model_nhanvien);
                    setLocationRelativeTo(null);
                    jDialog2.setLocationRelativeTo(null);
                    dlogDonHang.setLocationRelativeTo(null);
                    login_HashMap = new HashMap<>();
                String filelogin = "login.bin";
                File loginFile = new File(filelogin);
    
                try{
                    if(!loginFile.exists()){
                        loginFile.createNewFile();
                    }
                    
                  String mk1;
                  String tk1;
                  int quyen1;
                    DataInputStream loginDataInputStream = new DataInputStream(new FileInputStream(loginFile));
                   while(loginDataInputStream.available()>0){
                        tk1 = loginDataInputStream.readUTF();
                        mk1 = loginDataInputStream.readUTF();
                       login_HashMap.put(tk1, mk1);
                      
                   }
                   
                    
                }
                catch(IOException e){
                    System.out.println("Loi: "+e);
                }
                 dlogLogin.setSize(317,235);
                  dlogLogin.setLocationRelativeTo(null);
                 
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jDialog2 = new javax.swing.JDialog();
        txtTen = new javax.swing.JTextField();
        labTen = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        txtAge = new javax.swing.JTextField();
        txtHT = new javax.swing.JTextField();
        txtLuong = new javax.swing.JTextField();
        btnXacNhan = new javax.swing.JButton();
        btnCancel = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        cmbChucVU = new javax.swing.JComboBox<>();
        txtID = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        dlogDonHang = new javax.swing.JDialog();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        txtId = new javax.swing.JTextField();
        txtTenMon = new javax.swing.JTextField();
        txtDonGia = new javax.swing.JTextField();
        txtSoLuong = new javax.swing.JTextField();
        btnDonXacNhan = new javax.swing.JButton();
        btnHuyDon = new javax.swing.JButton();
        jComboBox1 = new javax.swing.JComboBox<>();
        jLabel20 = new javax.swing.JLabel();
        txtBanIDDH = new javax.swing.JTextField();
        dlogLogin = new javax.swing.JDialog();
        btnDangNhap = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        txtTaiKhoan = new javax.swing.JTextField();
        txtMatKhau = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        dlogDoiMK = new javax.swing.JDialog();
        txtMKCU = new javax.swing.JTextField();
        txtMKMoi = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        txtLaiMKMoi = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        dlogBan = new javax.swing.JDialog();
        jLabel10 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        txtBanId = new javax.swing.JTextField();
        txtLoaiBan = new javax.swing.JTextField();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        txtBanTT = new javax.swing.JComboBox<>();
        dlogSuaTen = new javax.swing.JDialog();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jLabel21 = new javax.swing.JLabel();
        txtChageID = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        txtChageTen = new javax.swing.JTextField();
        cboChageChucVu = new javax.swing.JComboBox<>();
        txtChageTuoi = new javax.swing.JTextField();
        txtChageLuong = new javax.swing.JTextField();
        jLabel27 = new javax.swing.JLabel();
        txtChageQue = new javax.swing.JTextField();
        dlogSuaDonHang = new javax.swing.JDialog();
        jLabel34 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        txtChageTenMon = new javax.swing.JTextField();
        txtChageDonGia = new javax.swing.JTextField();
        txtChageSoLuong = new javax.swing.JTextField();
        btnDonXacNhan1 = new javax.swing.JButton();
        btnHuyDon1 = new javax.swing.JButton();
        txtChageStatus = new javax.swing.JComboBox<>();
        jLabel39 = new javax.swing.JLabel();
        txtChageBanDonHang = new javax.swing.JTextField();
        labelChageDonHang = new javax.swing.JLabel();
        dlogidChageBan = new javax.swing.JDialog();
        jLabel22 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        txtChageType = new javax.swing.JTextField();
        jButton8 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        txtChageBanStatuc = new javax.swing.JComboBox<>();
        labelBan = new javax.swing.JLabel();
        btnOK = new javax.swing.JButton();
        labThongBao = new javax.swing.JLabel();
        btnXoa = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        txtTimKiem = new javax.swing.JTextField();
        btnTimKiem = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        mnFile = new javax.swing.JMenu();
        mnDoiMK = new javax.swing.JMenuItem();
        jMenu1 = new javax.swing.JMenu();
        mnNhanVien = new javax.swing.JMenuItem();
        mnDonDat = new javax.swing.JMenuItem();
        mnBan = new javax.swing.JMenuItem();

        jDialog2.setSize(576,308);

        txtTen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTenActionPerformed(evt);
            }
        });

        labTen.setText("Tên");

        jLabel6.setText("Tuổi");

        jLabel7.setText("Quê");

        jLabel8.setText("Lương");

        txtAge.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtAgeActionPerformed(evt);
            }
        });

        txtHT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtHTActionPerformed(evt);
            }
        });

        txtLuong.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtLuongActionPerformed(evt);
            }
        });

        btnXacNhan.setText("Xác Nhận");
        btnXacNhan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXacNhanActionPerformed(evt);
            }
        });

        btnCancel.setText("Cancel");
        btnCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelActionPerformed(evt);
            }
        });

        jLabel1.setText("Chức vụ");

        cmbChucVU.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Quản Lý", "Nhân Viên" }));
        cmbChucVU.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbChucVUActionPerformed(evt);
            }
        });

        jLabel12.setText("ID");

        javax.swing.GroupLayout jDialog2Layout = new javax.swing.GroupLayout(jDialog2.getContentPane());
        jDialog2.getContentPane().setLayout(jDialog2Layout);
        jDialog2Layout.setHorizontalGroup(
            jDialog2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jDialog2Layout.createSequentialGroup()
                .addGroup(jDialog2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jDialog2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jDialog2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jDialog2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jDialog2Layout.createSequentialGroup()
                                    .addGap(30, 30, 30)
                                    .addComponent(labTen, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jDialog2Layout.createSequentialGroup()
                                    .addGap(32, 32, 32)
                                    .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jDialog2Layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jDialog2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jDialog2Layout.createSequentialGroup()
                        .addComponent(btnXacNhan, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 39, Short.MAX_VALUE)
                        .addComponent(btnCancel, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(txtTen)
                    .addComponent(txtID)
                    .addComponent(txtAge, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(txtHT)
                    .addComponent(cmbChucVU, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(txtLuong, javax.swing.GroupLayout.Alignment.TRAILING))
                .addGap(121, 121, 121))
        );
        jDialog2Layout.setVerticalGroup(
            jDialog2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jDialog2Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(jDialog2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel12))
                .addGap(18, 18, 18)
                .addGroup(jDialog2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtTen, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(labTen))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jDialog2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(txtAge, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jDialog2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel7)
                    .addComponent(txtHT, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jDialog2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel8)
                    .addComponent(txtLuong, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(9, 9, 9)
                .addGroup(jDialog2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(cmbChucVU, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jDialog2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnXacNhan)
                    .addComponent(btnCancel))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        dlogDonHang.setSize(450,450);

        jLabel2.setText("ID");

        jLabel3.setText("Tên Món");

        jLabel4.setText("Đơn Giá");

        jLabel5.setText("Số Lượng");

        jLabel9.setText("Trạng Thái");

        btnDonXacNhan.setText("Xác Nhận");
        btnDonXacNhan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDonXacNhanActionPerformed(evt);
            }
        });

        btnHuyDon.setText("Cancel");
        btnHuyDon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHuyDonActionPerformed(evt);
            }
        });

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Chờ Xử Lý", "Hoàn Thành"
        }));

        jLabel20.setText("Ban");

        javax.swing.GroupLayout dlogDonHangLayout = new javax.swing.GroupLayout(dlogDonHang.getContentPane());
        dlogDonHang.getContentPane().setLayout(dlogDonHangLayout);
        dlogDonHangLayout.setHorizontalGroup(
            dlogDonHangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dlogDonHangLayout.createSequentialGroup()
                .addGroup(dlogDonHangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(dlogDonHangLayout.createSequentialGroup()
                        .addGap(35, 35, 35)
                        .addGroup(dlogDonHangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(dlogDonHangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, 58, Short.MAX_VALUE))
                            .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, dlogDonHangLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(dlogDonHangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, dlogDonHangLayout.createSequentialGroup()
                        .addComponent(btnDonXacNhan)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 130, Short.MAX_VALUE)
                        .addComponent(btnHuyDon, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(txtId)
                    .addComponent(txtTenMon)
                    .addComponent(txtDonGia)
                    .addComponent(txtSoLuong)
                    .addComponent(jComboBox1, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(txtBanIDDH))
                .addContainerGap(42, Short.MAX_VALUE))
        );
        dlogDonHangLayout.setVerticalGroup(
            dlogDonHangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dlogDonHangLayout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addGroup(dlogDonHangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(dlogDonHangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel20)
                    .addComponent(txtBanIDDH, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(dlogDonHangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(dlogDonHangLayout.createSequentialGroup()
                        .addGroup(dlogDonHangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(txtTenMon, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel4))
                    .addComponent(txtDonGia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(dlogDonHangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(txtSoLuong, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(dlogDonHangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(dlogDonHangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnDonXacNhan)
                    .addComponent(btnHuyDon))
                .addContainerGap(32, Short.MAX_VALUE))
        );

        dlogLogin.setLocation(new java.awt.Point(300, 300));

        btnDangNhap.setText("Đăng Nhập");
        btnDangNhap.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnDangNhapMouseClicked(evt);
            }
        });
        btnDangNhap.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDangNhapActionPerformed(evt);
            }
        });

        jLabel11.setText("Tài Khoản");

        jLabel13.setText("Mật Khẩu");

        txtTaiKhoan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTaiKhoanActionPerformed(evt);
            }
        });

        jLabel14.setText("Đăng Nhập");

        javax.swing.GroupLayout dlogLoginLayout = new javax.swing.GroupLayout(dlogLogin.getContentPane());
        dlogLogin.getContentPane().setLayout(dlogLoginLayout);
        dlogLoginLayout.setHorizontalGroup(
            dlogLoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dlogLoginLayout.createSequentialGroup()
                .addGroup(dlogLoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(dlogLoginLayout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addGroup(dlogLoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel11)
                            .addComponent(jLabel13))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(dlogLoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtMatKhau, javax.swing.GroupLayout.DEFAULT_SIZE, 172, Short.MAX_VALUE)
                            .addComponent(txtTaiKhoan)))
                    .addGroup(dlogLoginLayout.createSequentialGroup()
                        .addGap(109, 109, 109)
                        .addComponent(btnDangNhap))
                    .addGroup(dlogLoginLayout.createSequentialGroup()
                        .addGap(118, 118, 118)
                        .addComponent(jLabel14)))
                .addContainerGap(150, Short.MAX_VALUE))
        );
        dlogLoginLayout.setVerticalGroup(
            dlogLoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, dlogLoginLayout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addComponent(jLabel14)
                .addGap(18, 18, 18)
                .addGroup(dlogLoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel11)
                    .addComponent(txtTaiKhoan, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(dlogLoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13)
                    .addComponent(txtMatKhau, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(btnDangNhap)
                .addContainerGap(134, Short.MAX_VALUE))
        );

        jLabel15.setText("Mật Khẩu Cũ");

        jLabel16.setText("Mật Khẩu mới");

        jLabel17.setText("Nhập Lại Mật Khẩu");

        jButton1.setText("OK");
        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton1MouseClicked(evt);
            }
        });
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Cancel");
        jButton2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton2MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout dlogDoiMKLayout = new javax.swing.GroupLayout(dlogDoiMK.getContentPane());
        dlogDoiMK.getContentPane().setLayout(dlogDoiMKLayout);
        dlogDoiMKLayout.setHorizontalGroup(
            dlogDoiMKLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dlogDoiMKLayout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(dlogDoiMKLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel16)
                    .addComponent(jLabel17))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(dlogDoiMKLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(dlogDoiMKLayout.createSequentialGroup()
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 68, Short.MAX_VALUE)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(txtMKCU)
                    .addComponent(txtMKMoi)
                    .addComponent(txtLaiMKMoi))
                .addContainerGap(49, Short.MAX_VALUE))
        );
        dlogDoiMKLayout.setVerticalGroup(
            dlogDoiMKLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dlogDoiMKLayout.createSequentialGroup()
                .addGap(92, 92, 92)
                .addGroup(dlogDoiMKLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtMKCU, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel15))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(dlogDoiMKLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtMKMoi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel16))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(dlogDoiMKLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel17)
                    .addComponent(txtLaiMKMoi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(34, 34, 34)
                .addGroup(dlogDoiMKLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2))
                .addContainerGap(45, Short.MAX_VALUE))
        );

        dlogBan.setLocationRelativeTo(null);

        jLabel10.setText("ID");

        jLabel18.setText("Loại Bàn");

        jLabel19.setText("Trạng thái");

        txtLoaiBan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtLoaiBanActionPerformed(evt);
            }
        });

        jButton3.setText("OK");
        jButton3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton3MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton3MouseEntered(evt);
            }
        });
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setText("Cancel");
        jButton4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton4MouseClicked(evt);
            }
        });

        txtBanTT.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Mới","Hỏng" }));

        dlogBan.setSize(398,247);

        javax.swing.GroupLayout dlogBanLayout = new javax.swing.GroupLayout(dlogBan.getContentPane());
        dlogBan.getContentPane().setLayout(dlogBanLayout);
        dlogBanLayout.setHorizontalGroup(
            dlogBanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dlogBanLayout.createSequentialGroup()
                .addGap(55, 55, 55)
                .addGroup(dlogBanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel18, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel19, javax.swing.GroupLayout.DEFAULT_SIZE, 78, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(dlogBanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(dlogBanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(txtLoaiBan)
                        .addComponent(txtBanId)
                        .addComponent(txtBanTT, 0, 177, Short.MAX_VALUE))
                    .addGroup(dlogBanLayout.createSequentialGroup()
                        .addComponent(jButton3)
                        .addGap(39, 39, 39)
                        .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(67, Short.MAX_VALUE))
        );
        dlogBanLayout.setVerticalGroup(
            dlogBanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dlogBanLayout.createSequentialGroup()
                .addGap(70, 70, 70)
                .addGroup(dlogBanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(txtBanId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(dlogBanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel18)
                    .addComponent(txtLoaiBan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(dlogBanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel19)
                    .addComponent(txtBanTT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(dlogBanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton4)
                    .addGroup(dlogBanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jButton3)))
                .addContainerGap(52, Short.MAX_VALUE))
        );

        dlogSuaTen.setLocationRelativeTo(null);
        dlogSuaTen.setSize(427,328);

        jButton6.setText("cacel");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jButton7.setText("ok");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        jLabel21.setText("ID");

        txtChageID.setText("laeblId");

        jLabel23.setText("Tên");

        jLabel24.setText("Tuổi");

        jLabel25.setText("Quê");

        jLabel26.setText("Chức vụ");

        cboChageChucVu.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Quản lý", "Nhân viên"}));
        cboChageChucVu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboChageChucVuActionPerformed(evt);
            }
        });

        txtChageLuong.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtChageLuongActionPerformed(evt);
            }
        });

        jLabel27.setText("Lương");

        javax.swing.GroupLayout dlogSuaTenLayout = new javax.swing.GroupLayout(dlogSuaTen.getContentPane());
        dlogSuaTen.getContentPane().setLayout(dlogSuaTenLayout);
        dlogSuaTenLayout.setHorizontalGroup(
            dlogSuaTenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dlogSuaTenLayout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addGroup(dlogSuaTenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(dlogSuaTenLayout.createSequentialGroup()
                        .addComponent(jLabel26, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(dlogSuaTenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(dlogSuaTenLayout.createSequentialGroup()
                                .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(cboChageChucVu, javax.swing.GroupLayout.PREFERRED_SIZE, 225, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(dlogSuaTenLayout.createSequentialGroup()
                        .addGroup(dlogSuaTenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(dlogSuaTenLayout.createSequentialGroup()
                                .addGroup(dlogSuaTenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(dlogSuaTenLayout.createSequentialGroup()
                                        .addComponent(jLabel24)
                                        .addGap(49, 49, 49))
                                    .addGroup(dlogSuaTenLayout.createSequentialGroup()
                                        .addComponent(jLabel23, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGap(30, 30, 30)))
                                .addGroup(dlogSuaTenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtChageTuoi, javax.swing.GroupLayout.PREFERRED_SIZE, 225, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtChageTen, javax.swing.GroupLayout.PREFERRED_SIZE, 225, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(dlogSuaTenLayout.createSequentialGroup()
                                .addGroup(dlogSuaTenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(jLabel25, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel27, javax.swing.GroupLayout.DEFAULT_SIZE, 43, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(dlogSuaTenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtChageLuong, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 225, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtChageQue, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 225, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(dlogSuaTenLayout.createSequentialGroup()
                                .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(txtChageID, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(97, 97, 97)))
                        .addContainerGap(88, Short.MAX_VALUE))))
        );
        dlogSuaTenLayout.setVerticalGroup(
            dlogSuaTenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dlogSuaTenLayout.createSequentialGroup()
                .addGap(64, 64, 64)
                .addGroup(dlogSuaTenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel21)
                    .addComponent(txtChageID))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(dlogSuaTenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel23)
                    .addComponent(txtChageTen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(dlogSuaTenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtChageTuoi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel24))
                .addGap(7, 7, 7)
                .addGroup(dlogSuaTenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel25)
                    .addComponent(txtChageQue, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(dlogSuaTenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel27)
                    .addComponent(txtChageLuong, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(dlogSuaTenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel26)
                    .addComponent(cboChageChucVu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 37, Short.MAX_VALUE)
                .addGroup(dlogSuaTenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton7)
                    .addComponent(jButton6))
                .addGap(29, 29, 29))
        );

        dlogSuaDonHang.setSize(450,450);
        dlogSuaDonHang.setLocationRelativeTo(null);

        jLabel34.setText("ID");

        jLabel35.setText("Tên Món");

        jLabel36.setText("Đơn Giá");

        jLabel37.setText("Số Lượng");

        jLabel38.setText("Trạng Thái");

        btnDonXacNhan1.setText("Xác Nhận");
        btnDonXacNhan1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDonXacNhan1ActionPerformed(evt);
            }
        });

        btnHuyDon1.setText("Cancel");
        btnHuyDon1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHuyDon1ActionPerformed(evt);
            }
        });

        txtChageStatus.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Chờ Xử Lý", "Hoàn thành"

        }));

        jLabel39.setText("Ban");

        labelChageDonHang.setText("IDD");

        javax.swing.GroupLayout dlogSuaDonHangLayout = new javax.swing.GroupLayout(dlogSuaDonHang.getContentPane());
        dlogSuaDonHang.getContentPane().setLayout(dlogSuaDonHangLayout);
        dlogSuaDonHangLayout.setHorizontalGroup(
            dlogSuaDonHangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dlogSuaDonHangLayout.createSequentialGroup()
                .addGroup(dlogSuaDonHangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(dlogSuaDonHangLayout.createSequentialGroup()
                        .addGap(35, 35, 35)
                        .addGroup(dlogSuaDonHangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(dlogSuaDonHangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(jLabel35, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel36, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel37, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel38, javax.swing.GroupLayout.DEFAULT_SIZE, 58, Short.MAX_VALUE))
                            .addComponent(jLabel39, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, dlogSuaDonHangLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel34, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(dlogSuaDonHangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(dlogSuaDonHangLayout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(dlogSuaDonHangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, dlogSuaDonHangLayout.createSequentialGroup()
                                .addComponent(btnDonXacNhan1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 130, Short.MAX_VALUE)
                                .addComponent(btnHuyDon1, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(txtChageTenMon)
                            .addComponent(txtChageDonGia)
                            .addComponent(txtChageSoLuong)
                            .addComponent(txtChageStatus, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtChageBanDonHang)))
                    .addGroup(dlogSuaDonHangLayout.createSequentialGroup()
                        .addGap(116, 116, 116)
                        .addComponent(labelChageDonHang, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(42, Short.MAX_VALUE))
        );
        dlogSuaDonHangLayout.setVerticalGroup(
            dlogSuaDonHangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dlogSuaDonHangLayout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addGroup(dlogSuaDonHangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel34)
                    .addComponent(labelChageDonHang))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(dlogSuaDonHangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel39)
                    .addComponent(txtChageBanDonHang, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(dlogSuaDonHangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(dlogSuaDonHangLayout.createSequentialGroup()
                        .addGroup(dlogSuaDonHangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel35)
                            .addComponent(txtChageTenMon, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel36))
                    .addComponent(txtChageDonGia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(dlogSuaDonHangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel37)
                    .addComponent(txtChageSoLuong, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(dlogSuaDonHangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel38)
                    .addComponent(txtChageStatus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(dlogSuaDonHangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnDonXacNhan1)
                    .addComponent(btnHuyDon1))
                .addContainerGap(35, Short.MAX_VALUE))
        );

        dlogidChageBan.setLocationRelativeTo(null);

        jLabel22.setText("ID");

        jLabel28.setText("Loại Bàn");

        jLabel29.setText("Trạng thái");

        jButton8.setText("OK");
        jButton8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton8MouseClicked(evt);
            }
        });
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });

        jButton9.setText("Cancel");
        jButton9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton9MouseClicked(evt);
            }
        });
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });

        txtChageBanStatuc.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Mới","Hỏng"}));

        labelBan.setText("idd");

        dlogidChageBan.setSize(398,247);

        javax.swing.GroupLayout dlogidChageBanLayout = new javax.swing.GroupLayout(dlogidChageBan.getContentPane());
        dlogidChageBan.getContentPane().setLayout(dlogidChageBanLayout);
        dlogidChageBanLayout.setHorizontalGroup(
            dlogidChageBanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dlogidChageBanLayout.createSequentialGroup()
                .addGap(55, 55, 55)
                .addGroup(dlogidChageBanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jLabel22, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel28, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel29, javax.swing.GroupLayout.DEFAULT_SIZE, 78, Short.MAX_VALUE))
                .addGroup(dlogidChageBanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(dlogidChageBanLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(dlogidChageBanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(dlogidChageBanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(txtChageType)
                                .addComponent(txtChageBanStatuc, 0, 177, Short.MAX_VALUE))
                            .addGroup(dlogidChageBanLayout.createSequentialGroup()
                                .addComponent(jButton8)
                                .addGap(39, 39, 39)
                                .addComponent(jButton9, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(dlogidChageBanLayout.createSequentialGroup()
                        .addGap(70, 70, 70)
                        .addComponent(labelBan, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(67, Short.MAX_VALUE))
        );
        dlogidChageBanLayout.setVerticalGroup(
            dlogidChageBanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dlogidChageBanLayout.createSequentialGroup()
                .addGap(73, 73, 73)
                .addGroup(dlogidChageBanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel22)
                    .addComponent(labelBan))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(dlogidChageBanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel28)
                    .addComponent(txtChageType, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(dlogidChageBanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel29)
                    .addComponent(txtChageBanStatuc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(dlogidChageBanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton9)
                    .addComponent(jButton8))
                .addContainerGap(55, Short.MAX_VALUE))
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Phuoc");
        setBackground(getBackground());
        setSize(new java.awt.Dimension(300, 300));
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowActivated(java.awt.event.WindowEvent evt) {
                formWindowActivated(evt);
            }
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        btnOK.setBackground(new java.awt.Color(0, 0, 153));
        btnOK.setForeground(new java.awt.Color(102, 255, 0));
        btnOK.setText("Thêm");
        btnOK.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnOKMouseClicked(evt);
            }
        });
        btnOK.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnOKActionPerformed(evt);
            }
        });

        btnXoa.setBackground(new java.awt.Color(51, 0, 153));
        btnXoa.setForeground(new java.awt.Color(153, 255, 51));
        btnXoa.setText("Xoa");
        btnXoa.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnXoaMouseClicked(evt);
            }
        });
        btnXoa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXoaActionPerformed(evt);
            }
        });

        jTable1.setBackground(new java.awt.Color(255, 102, 102));
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null,null,null,null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        txtTimKiem.addInputMethodListener(new java.awt.event.InputMethodListener() {
            public void caretPositionChanged(java.awt.event.InputMethodEvent evt) {
            }
            public void inputMethodTextChanged(java.awt.event.InputMethodEvent evt) {
                txtTimKiemInputMethodTextChanged(evt);
            }
        });
        txtTimKiem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTimKiemActionPerformed(evt);
            }
        });

        btnTimKiem.setBackground(new java.awt.Color(0, 153, 0));
        btnTimKiem.setText("Tìm Kiếm");
        btnTimKiem.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnTimKiemMouseClicked(evt);
            }
        });
        btnTimKiem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTimKiemActionPerformed(evt);
            }
        });

        jButton5.setBackground(new java.awt.Color(51, 0, 153));
        jButton5.setForeground(new java.awt.Color(102, 255, 102));
        jButton5.setText("Sua");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jMenuBar1.setBackground(new java.awt.Color(204, 204, 255));

        mnFile.setText("File");

        mnDoiMK.setText("Đổi Mật Khẩu");
        mnDoiMK.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnDoiMKActionPerformed(evt);
            }
        });
        mnFile.add(mnDoiMK);

        jMenuBar1.add(mnFile);

        jMenu1.setText("View");

        mnNhanVien.setText("Nhân Viên");
        mnNhanVien.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mnNhanVienMouseClicked(evt);
            }
        });
        mnNhanVien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnNhanVienActionPerformed(evt);
            }
        });
        jMenu1.add(mnNhanVien);

        mnDonDat.setText("Đơn Đặt");
        mnDonDat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnDonDatActionPerformed(evt);
            }
        });
        jMenu1.add(mnDonDat);

        mnBan.setText("Bàn");
        mnBan.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mnBanMouseClicked(evt);
            }
        });
        mnBan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnBanActionPerformed(evt);
            }
        });
        jMenu1.add(mnBan);

        jMenuBar1.add(jMenu1);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 386, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(258, 258, 258)
                        .addComponent(labThongBao, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(txtTimKiem, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnTimKiem))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnOK, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btnXoa, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(159, 159, 159)
                .addComponent(labThongBao)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 305, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(104, 104, 104))
            .addGroup(layout.createSequentialGroup()
                .addGap(92, 92, 92)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtTimKiem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnTimKiem))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnOK)
                    .addComponent(btnXoa)
                    .addComponent(jButton5))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
public static void main(String args[]) {
    
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                frmPhuoc frmPhuoc = new frmPhuoc();
//                 frmPhuoc.setVisible(true);
                frmPhuoc.dlogLogin.setVisible(true);
              
            }
//           

           
        });

    
        
}

    private void btnOKActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnOKActionPerformed
         dlogLogin.setVisible(false);
         if("admin".equals(tk)||phanquyen.get(Integer.valueOf(tk))==1){
             switch (view) {
                 case 1 -> jDialog2.setVisible(true);
                 case 2 -> dlogDonHang.setVisible(true);
                 default -> dlogBan.setVisible(true);
             }
        }
        else{
                    if(view ==2){
                        dlogDonHang.setVisible(true);
                    }
                    else{
                        showMess("Bạn không có quyền thêm");
                    }
        }
        
        
    }//GEN-LAST:event_btnOKActionPerformed

    private void btnOKMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnOKMouseClicked
        // TODO add your handling code here:
        
    }//GEN-LAST:event_btnOKMouseClicked

    private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated

    }//GEN-LAST:event_formWindowActivated

    private void btnXoaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnXoaMouseClicked
         if("admin".equals(tk)||phanquyen.get(Integer.valueOf(tk))==1||view==2){
             if(view==3){
                    int indexRow = jTable1.getSelectedRow();
                    int rowCount = jTable1.getRowCount();
                    DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
                    if (indexRow >= 0 && indexRow < rowCount) {
                       String idban = model.getValueAt(indexRow, 0).toString();
                       banHashSet.remove(Integer.parseInt(idban));
                       stBan1.remove(Integer.parseInt(idban));
                       model.removeRow(indexRow);
                        for (int row = (model_don_hang.getRowCount()-1); row >=0; row--) {
                            if(model_don_hang.getValueAt(row,1 ).toString() == null ? idban == null : model_don_hang.getValueAt(row,1 ).toString().equals(idban)){
                                model_don_hang.removeRow(row);
                            } 

                         }
                    } 
                   
               
             }
             else if(view==1){
                    int indexRow = jTable1.getSelectedRow();
                    int rowCount = jTable1.getRowCount();
                    DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
                    if (indexRow >= 0 && indexRow < rowCount) {
                       String a = model.getValueAt(indexRow, 0).toString();
                       if(login_HashMap.get(a)!=null)
                       login_HashMap.remove(a);
                       phanquyen.remove(Integer.parseInt(a));
                       person.remove(Integer.parseInt(a));

                       model.removeRow(indexRow);
                    }
                   
             }
             else{
                  int indexRow = jTable1.getSelectedRow();
                    int rowCount = jTable1.getRowCount();
                    DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
                    if (indexRow >= 0 && indexRow < rowCount) {
                       String a = model.getValueAt(indexRow, 0).toString();
                       model.removeRow(indexRow);
                    }
                    else {
            // handle the error or do nothing
                    }
                 
             }
                   
        }
        else{
             
                    showMess("Bạn không có quyền xóa");
        }
         
        
        
    }//GEN-LAST:event_btnXoaMouseClicked

    private void btnXacNhanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXacNhanActionPerformed
        // TODO add your handling code here:
        DefaultTableModel nextModel = (DefaultTableModel)jTable1.getModel();
        String hoten = txtTen.getText();
        String diachi = txtHT.getText();
       
        Pattern pattern = Pattern.compile("\\d");

    try {
       if(!"".equals(txtID.getText())&&!"".equals(hoten)&&!"".equals(diachi)&&txtLuong.getText()!=""&&txtAge.getText()!=""){
           
            int tuoi = Integer.parseInt(txtAge.getText());
            double luong = Double.parseDouble(txtLuong.getText());
            if(luong<=0){
                txtLuong.setText("");
                JOptionPane.showMessageDialog(null, "Nhập lại lương đi", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            
            String chucvu = (String) cmbChucVU.getSelectedItem();
            int id = Integer.parseInt(txtID.getText());
            if(id<=0){
                txtID.setText("");
                JOptionPane.showMessageDialog(null, "Id lớn hơn 0", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            if(person.contains(id)){
                 txtID.setText("");
                JOptionPane.showMessageDialog(null, "Id đã tồn tại", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            if(tuoi<18){
                txtAge.setText("");
                JOptionPane.showMessageDialog(null, "Tuổi không dưới 18", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
                return;
            }

            
            Matcher matcher = pattern.matcher(hoten);

            if (!matcher.find()) {
            } else {
                JOptionPane.showMessageDialog(null, "Tên không chứa số", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            matcher = pattern.matcher(diachi);
             if (!matcher.find()) {
            } else {
                JOptionPane.showMessageDialog(null, "Quê không chứa số", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            if(hoten.length()>=10){
                JOptionPane.showMessageDialog(null, "Tên quá dài", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            Object [] row = {id,hoten,tuoi,diachi,luong,chucvu};
            nextModel.addRow(row);
            nextModel.fireTableDataChanged();
            txtTen.setText("");
            txtHT.setText("");
            txtAge.setText("");
            txtLuong.setText("");
            txtID.setText("");
            login_HashMap.put(String.valueOf(id),String.valueOf(1));
            if("Quản Lý".equals(chucvu)){
                phanquyen.put(id, 1);
            }
            else{
                phanquyen.put(id, 0);
            }
            
            showMess("Thêm Thành Công");
            jDialog2.setVisible(false);
          
           
            
            
        }
       else{
           JOptionPane.showMessageDialog(null, "Nhập thiếu trường thông tin", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
       }
       
    } catch (NumberFormatException e) {
       JOptionPane.showMessageDialog(null, "Bạn nhập sai rồi", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
    }
    }//GEN-LAST:event_btnXacNhanActionPerformed

    private void txtTenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTenActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTenActionPerformed

    private void txtHTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtHTActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtHTActionPerformed

    private void btnCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelActionPerformed
        txtTen.setText("");
        txtHT.setText("");
        txtAge.setText("");
        txtLuong.setText("");
        jDialog2.setVisible(false);
    }//GEN-LAST:event_btnCancelActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        String fileName;
        fileName = "nhanvien.bin";
        String fileDonHang = "donhang.bin";
        try{
            DataOutputStream myDataOutputStream = new DataOutputStream(new FileOutputStream(fileName));
            DefaultTableModel table = model_nhanvien;
   
            for (int row = 0; row < table.getRowCount(); row++) {
                myDataOutputStream.writeInt(Integer.parseInt( table.getValueAt(row,0).toString()));
   
                myDataOutputStream.writeUTF(String.valueOf(table.getValueAt(row,1)));
                myDataOutputStream.writeInt(Integer.parseInt(table.getValueAt(row,2).toString()));
                myDataOutputStream.writeUTF(String.valueOf(table.getValueAt(row,3)));
                myDataOutputStream.writeFloat(Float.parseFloat(table.getValueAt(row,4).toString()));
                myDataOutputStream.writeUTF(String.valueOf(table.getValueAt(row,5)));
                
            }
            myDataOutputStream.close();
            DataOutputStream donhangdata = new DataOutputStream(new FileOutputStream(fileDonHang));
             table = model_don_hang;
   
            for (int row = 0; row < table.getRowCount(); row++) {
                donhangdata.writeInt(Integer.parseInt(table.getValueAt(row, 0).toString()));
                donhangdata.writeInt(Integer.parseInt( table.getValueAt(row,1).toString()));
                donhangdata.writeUTF(table.getValueAt(row,2).toString());
                donhangdata.writeFloat(Float.parseFloat(table.getValueAt(row,3).toString()));
                donhangdata.writeInt(Integer.parseInt(table.getValueAt(row, 4).toString()));
                donhangdata.writeUTF(String.valueOf(table.getValueAt(row,5)));
                donhangdata.writeUTF(String.valueOf(table.getValueAt(row,6)));
            }
            donhangdata.close();
            fileName = "login.bin";
            
            myDataOutputStream = new DataOutputStream(new FileOutputStream(fileName));
            myDataOutputStream.writeUTF("admin");
            myDataOutputStream.writeUTF("1");
            for (String tkString : login_HashMap.keySet()) {
                myDataOutputStream.writeUTF(tkString);
                myDataOutputStream.writeUTF(login_HashMap.get(tkString));
            }
            
            fileName = "ban.bin";
            
            table = model_ban;
            donhangdata = new DataOutputStream(new FileOutputStream(fileName));
            for (int row = 0; row < table.getRowCount(); row++) {
                donhangdata.writeInt(Integer.parseInt(table.getValueAt(row, 0).toString()));
               
               
                donhangdata.writeUTF(String.valueOf(table.getValueAt(row,1)));
                donhangdata.writeUTF(String.valueOf(table.getValueAt(row,2)));
            }
            donhangdata.close();
        }
        catch(IOException e){
            System.out.println("Loi: "+e);
        }
     
        
    }//GEN-LAST:event_formWindowClosing

    private void mnNhanVienMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mnNhanVienMouseClicked
           
    }//GEN-LAST:event_mnNhanVienMouseClicked

    private void mnNhanVienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnNhanVienActionPerformed
        // TODO add your handling code here:
  
        jTable1.setModel(model_nhanvien);
        view = 1;
    }//GEN-LAST:event_mnNhanVienActionPerformed

    private void btnDonXacNhanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDonXacNhanActionPerformed
        DefaultTableModel nextModel = (DefaultTableModel)jTable1.getModel();
        String tenmon = txtTenMon.getText();
        String status = jComboBox1.getSelectedItem().toString();
        String maban = txtBanIDDH.getText();
        try {
           if(!"".equals(maban)&&!"".equals(tenmon)&&!"".equals(txtId.getText())&&txtSoLuong.getText()!=""&&!"".equals(txtDonGia.getText())){
                if(txtId.getText().length()!=5){
                    txtId.setText("");
                    JOptionPane.showMessageDialog(null, "ID gồm 5 số", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
                    return;
                }
                int maban_int = Integer.parseInt(maban);
                if(banHashSet.contains(maban_int)==false){
                    JOptionPane.showMessageDialog(null, "Ban khong ton tai", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
                    return;
                }
                int ID = Integer.parseInt(txtId.getText());
                if(ID<=0){
                    txtId.setText("");
                    JOptionPane.showMessageDialog(null, "ID không được nhỏ hơn 0", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
                    return;
                }
               
                float dongia = Float.parseFloat(txtDonGia.getText());
                if(dongia<=0){
                txtDonGia.setText("");
                JOptionPane.showMessageDialog(null, "Đơn giá không đúng", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
                int soluong = Integer.parseInt(txtSoLuong.getText());
            if(soluong<=0){
                txtSoLuong.setText("");
                JOptionPane.showMessageDialog(null, "Nhập lại đi", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            if(stBan1.get(maban_int)==0){
                txtBanIDDH.setText("");
                showMess("Bàn bị hỏng rồi k sử dụng");
                return;
            }
               

            LocalDateTime currentTime = LocalDateTime.now();
            String time = String.valueOf(currentTime.getYear());
            time += "/" +currentTime.getMonthValue();
            time += "/"+currentTime.getDayOfMonth();

                Object [] row = {ID,maban_int,tenmon,dongia,soluong,status,time};
                nextModel.addRow(row);
                nextModel.fireTableDataChanged();
                
                txtTenMon.setText("");
                txtId.setText("");

                txtSoLuong.setText("");
  
                txtDonGia.setText("");
                txtBanIDDH.setText("");
                dlogDonHang.setVisible(false);
            }
           else{
               JOptionPane.showMessageDialog(null, "Nhập thiếu trường thông tin", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
           }
       
        } catch (NumberFormatException e) {
           JOptionPane.showMessageDialog(null, "Bạn nhập sai rồi", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
        }
    }//GEN-LAST:event_btnDonXacNhanActionPerformed

    private void mnDonDatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnDonDatActionPerformed
         try {
            model_don_hang.fireTableDataChanged();
            jTable1.setModel(model_don_hang);
             
        } catch (Exception e) {
        }
         view =2;
        
    }//GEN-LAST:event_mnDonDatActionPerformed

    private void btnHuyDonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHuyDonActionPerformed
                txtTenMon.setText("");
                txtId.setText("");
       
                txtSoLuong.setText("");
                txtDonGia.setText("");
                txtBanIDDH.setText("");
                dlogDonHang.setVisible(false);
    }//GEN-LAST:event_btnHuyDonActionPerformed

    private void btnXoaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXoaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnXoaActionPerformed

    private void txtTimKiemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTimKiemActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTimKiemActionPerformed

    private void cmbChucVUActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbChucVUActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbChucVUActionPerformed

    private void txtAgeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtAgeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtAgeActionPerformed

    private void txtLuongActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtLuongActionPerformed
        
    }//GEN-LAST:event_txtLuongActionPerformed

    private void btnTimKiemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTimKiemActionPerformed
       
    }//GEN-LAST:event_btnTimKiemActionPerformed

    private void btnTimKiemMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnTimKiemMouseClicked
    try{
       
    
        String searchString = txtTimKiem.getText().trim();
        System.out.println(searchString);
        if (searchString.length() == 0) {
            // empty search field, show all rows
            TableRowSorter<TableModel> rowSorter = (TableRowSorter<TableModel>) jTable1.getRowSorter();
            if (rowSorter != null) {
                rowSorter.setRowFilter(null);
            }
        } else {
            // create row sorter with filter based on search string
            TableRowSorter<TableModel> rowSorter = new TableRowSorter<>(jTable1.getModel());
            
           rowSorter.setRowFilter(RowFilter.regexFilter("(?i)" + searchString));
            jTable1.setRowSorter(rowSorter);
           
        }

    }
    catch(Exception e){
        System.out.println(e);
    }
    }//GEN-LAST:event_btnTimKiemMouseClicked

    private void btnDangNhapMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnDangNhapMouseClicked
        // TODO add your handling code here:tk = txtTaiKhoan.getText();
        mk = txtMatKhau.getText();
        tk = txtTaiKhoan.getText();
        if(tk.length()==0){
            JOptionPane.showMessageDialog(null, "Nhập thiếu trường thông tin tài khoản", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        if(mk.length()==0){
            JOptionPane.showMessageDialog(null, "Nhập thiếu trường thông tin mật khẩu", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        String mk_check =login_HashMap.get(tk);
        if( (mk) == null ? login_HashMap.get(tk) == null : (mk).equals(login_HashMap.get(tk))){
            JOptionPane.showMessageDialog(null, "Đăng nhập thành công", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
    
                setVisible(true);
                dlogLogin.setVisible(false);
                
                
         
        }
        else{
            JOptionPane.showMessageDialog(null, "Tài khoản hoặc mật khẩu không đúng", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
        }
    }//GEN-LAST:event_btnDangNhapMouseClicked
  
    private void btnDangNhapActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDangNhapActionPerformed
        // TODO add your handling code here:

    }//GEN-LAST:event_btnDangNhapActionPerformed

    private void txtTaiKhoanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTaiKhoanActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTaiKhoanActionPerformed

    private void txtTimKiemInputMethodTextChanged(java.awt.event.InputMethodEvent evt) {//GEN-FIRST:event_txtTimKiemInputMethodTextChanged
        
    }//GEN-LAST:event_txtTimKiemInputMethodTextChanged

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed
    private void showMess(String txt){
        JOptionPane.showMessageDialog(null, txt, "Thông báo", JOptionPane.INFORMATION_MESSAGE);
    }
    private void jButton1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MouseClicked
        
         if(tk.equals("admin")){
            JOptionPane.showMessageDialog(null, "Khong the doi mk admin", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        String mkcu = txtMKCU.getText();
        if(mkcu.equals("")){
            JOptionPane.showMessageDialog(null, "Nhập thiếu trường thông tin mật khẩu", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        if(!mkcu.equals(mk)){
            showMess("Mật khẩu sai");
            return;
        }
        String mkmoi1 = txtMKMoi.getText();
        if(mkmoi1.equals("")){
            showMess("Mật khẩu mới không để trống");
            return;
        }
        String mkmoi2 = txtLaiMKMoi.getText();
        if(mkmoi2.equals("")){
            showMess("Mật khẩu mới nhập lại không để trống");
            return;
        }
        if(!mkmoi1.equals(mkmoi2)){
            showMess("Mật khẩu xác nhận không trung khớp");
            txtLaiMKMoi.setText("");
            return;
        }
        mk = mkmoi1;
        login_HashMap.replace(tk, mkmoi1);
        showMess("Đổi mật khẩu thành công");
        txtMKCU.setText("");
        txtMKMoi.setText("");
        txtLaiMKMoi.setText("");
        dlogDoiMK.setVisible(false);
       
    }//GEN-LAST:event_jButton1MouseClicked

    private void jButton2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton2MouseClicked
        // TODO add your handling code here:
        txtMKCU.setText("");
        txtMKMoi.setText("");
        txtLaiMKMoi.setText("");
        dlogDoiMK.setLocationRelativeTo(null);
        dlogDoiMK.setVisible(false);

    }//GEN-LAST:event_jButton2MouseClicked

    private void mnDoiMKActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnDoiMKActionPerformed
        dlogDoiMK.setVisible(true);
    }//GEN-LAST:event_mnDoiMKActionPerformed

    private void mnBanMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mnBanMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_mnBanMouseClicked

    private void jButton4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton4MouseClicked
        txtBanId.setText("");
        txtLoaiBan.setText("");
        dlogBan.setVisible(false);
    }//GEN-LAST:event_jButton4MouseClicked

    private void mnBanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnBanActionPerformed
        model_ban.fireTableDataChanged();
        jTable1.setModel(model_ban);
        view = 3;
        
    }//GEN-LAST:event_mnBanActionPerformed

    private void jButton3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton3MouseClicked
            DefaultTableModel nextModel = (DefaultTableModel)jTable1.getModel();
            Ban new_ban = new Ban();
            String idString = txtBanId.getText();
            String txtTT =  (txtBanTT.getSelectedItem()).toString();
            String txtLoai = txtLoaiBan.getText();
            try{
                
                new_ban.setLoai_ban(txtLoai);
                new_ban.setMa(idString);
               
                if(banHashSet.contains(Integer.valueOf(idString))){
                    showMess("Bàn đã tồn tại");
                    return;
                }
                new_ban.setTrang_thai(txtTT);
                Object [] row = {idString,txtLoai,txtTT};
                nextModel.addRow(row);
                nextModel.fireTableDataChanged();
                banHashSet.add(Integer.valueOf(idString));
                System.out.println(txtTT);
                if("Mới".equals(txtTT)){
                    stBan1.put(Integer.valueOf(idString),1);
                }
                else{
                    stBan1.put(Integer.valueOf(idString),0);
                }
                       
                txtBanId.setText("");
                txtLoaiBan.setText("");
                dlogBan.setVisible(false);
            }
            catch(IllegalArgumentException e ){
                showMess(e.getMessage());
                txtBanId.setText("");
                txtLoaiBan.setText("");
            }

            
    }//GEN-LAST:event_jButton3MouseClicked

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        dlogSuaTen.setVisible(false);
    }//GEN-LAST:event_jButton6ActionPerformed

    private void txtChageLuongActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtChageLuongActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtChageLuongActionPerformed

    private void cboChageChucVuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboChageChucVuActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cboChageChucVuActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        DefaultTableModel nextModel = (DefaultTableModel) jTable1.getModel();
        String hoten = txtChageTen.getText();
        String diachi = txtChageQue.getText();
       
        Pattern pattern = Pattern.compile("\\d");

    try {
       if(!"".equals(hoten)&&!"".equals(diachi)&&txtChageLuong.getText()!=""&&txtChageTuoi.getText()!=""){
           
            int tuoi = Integer.parseInt(txtChageTuoi.getText());
            double luong = Double.parseDouble(txtChageLuong.getText());
            if(luong<=0){
                txtChageLuong.setText("");
                JOptionPane.showMessageDialog(null, "Nhập lại lương đi", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            
            String chucvu = (String) cboChageChucVu.getSelectedItem();
            int id = Integer.parseInt(txtChageID.getText());
            
            
            if(tuoi<18){
                txtAge.setText("");
                JOptionPane.showMessageDialog(null, "Tuổi không dưới 18", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
                return;
            }

            
            Matcher matcher = pattern.matcher(hoten);

            if (!matcher.find()) {
            } else {
                JOptionPane.showMessageDialog(null, "Tên không chứa số", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            matcher = pattern.matcher(diachi);
             if (!matcher.find()) {
            } else {
                JOptionPane.showMessageDialog(null, "Quê không chứa số", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            if(hoten.length()>=10){
                JOptionPane.showMessageDialog(null, "Tên quá dài", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            Object [] row = {id,hoten,tuoi,diachi,luong,chucvu};
            nextModel.removeRow(select);
            nextModel.addRow(row);
            nextModel.fireTableDataChanged();
//            txtTen.setText("");
//            txtHT.setText("");
//            txtAge.setText("");
//            txtLuong.setText("");
//            txtID.setText("");
            
            if("Quản Lý".equals(chucvu)){
                phanquyen.replace(id, 1);
            }
            else{
                phanquyen.replace(id, 0);
            }
            
            showMess("Sua Thành Công");
            dlogSuaTen.setVisible(false);
            }
       else{
           JOptionPane.showMessageDialog(null, "Nhập thiếu trường thông tin", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
       }
       
    }
    catch (NumberFormatException e) {
       JOptionPane.showMessageDialog(null, "Bạn nhập sai rồi", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
    }
           
        

    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
    int indexRow = jTable1.getSelectedRow();
    int rowCount = jTable1.getRowCount();
    DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
    if (indexRow >= 0 && indexRow < rowCount) {
        select = indexRow;
    }
    else{
        select = -1;
    }
   if(view==1) { 
        if("admin".equals(tk)||phanquyen.get(tk)==1){
                       
                    if (indexRow >= 0 && indexRow < rowCount) {
                       String a = model.getValueAt(indexRow, 0).toString();
                       txtChageID.setText(model.getValueAt(indexRow, 0).toString());
                       txtChageTen.setText(model.getValueAt(indexRow, 1).toString());
                       txtChageTuoi.setText(model.getValueAt(indexRow, 2).toString());
                       txtChageQue.setText(model.getValueAt(indexRow, 3).toString());
                       txtChageLuong.setText(model.getValueAt(indexRow, 4).toString());
                    
                       cboChageChucVu.setSelectedIndex(1-phanquyen.get(Integer.parseInt(model.getValueAt(indexRow, 0).toString())));
                       dlogSuaTen.setVisible(true);


                      } 
                    else {
                       
            // handle the error or do nothing
                    }



            }
            else{
            
                showMess("Ban khong co quyen");
            }
     }
        System.out.println(view);
   if(view==2){
        if (indexRow >= 0 && indexRow < rowCount) {
            String id = model.getValueAt(indexRow, 0).toString();
            txtChageBanDonHang.setText(model.getValueAt(indexRow, 1).toString());
            txtChageTenMon.setText(model.getValueAt(indexRow, 2).toString());
            txtChageDonGia.setText(model.getValueAt(indexRow, 3).toString());
            txtChageSoLuong.setText(model.getValueAt(indexRow, 4).toString());
            labelChageDonHang.setText(id);
            if(model.getValueAt(indexRow, 5).toString()=="Hoàn Thành"){
                txtChageStatus.setSelectedIndex(1);
            }
            else{
                txtChageStatus.setSelectedIndex(0);
            }
      
            
            dlogSuaDonHang.setVisible(true);
        }
        
   }
   if(view==3) { 
        if("admin".equals(tk)||phanquyen.get(tk)==1){
                       
                    if (indexRow >= 0 && indexRow < rowCount) {
                       String a = model.getValueAt(indexRow, 0).toString();
                       labelBan.setText(model.getValueAt(indexRow, 0).toString());
                       txtChageType.setText(model.getValueAt(indexRow, 1).toString());
                       
                     if(model.getValueAt(indexRow, 2).toString()=="Hỏng"){
                        txtChageBanStatuc.setSelectedIndex(1);
                    }
                    else{
                        txtChageBanStatuc.setSelectedIndex(0);
                    }
                    dlogidChageBan.setVisible(true);

                       
                      } 
                    else {
                       
            // handle the error or do nothing
                    }



            }
            else{
            
                showMess("Ban khong co quyen");
            }
     }
    }//GEN-LAST:event_jButton5ActionPerformed

    private void btnDonXacNhan1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDonXacNhan1ActionPerformed
        DefaultTableModel nextModel = (DefaultTableModel)jTable1.getModel();
        String tenmon = txtChageTenMon.getText();
        String status = txtChageStatus.getSelectedItem().toString();
        String maban = txtChageBanDonHang.getText();
        try {
           if(!"".equals(maban)&&!"".equals(tenmon)&&!"".equals(labelChageDonHang.getText())&&txtChageSoLuong.getText()!=""&&!"".equals(txtChageDonGia.getText())){
                
                int maban_int = Integer.parseInt(maban);
                if(banHashSet.contains(maban_int)==false){
                    JOptionPane.showMessageDialog(null, "Ban khong ton tai", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
                    return;
                }
                
               
                float dongia = Float.parseFloat(txtChageDonGia.getText());
                if(dongia<=0){
                txtDonGia.setText("");
                JOptionPane.showMessageDialog(null, "Đơn giá không đúng", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
                int soluong = Integer.parseInt(txtChageSoLuong.getText());
                if(soluong<=0){
                txtSoLuong.setText("");
                JOptionPane.showMessageDialog(null, "Nhập lại đi", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
               

            LocalDateTime currentTime = LocalDateTime.now();
            String time = String.valueOf(currentTime.getYear());
            time += "/" +currentTime.getMonthValue();
            time += "/"+currentTime.getDayOfMonth();
                  String ID = labelChageDonHang.getText();
                nextModel.removeRow(select);
                Object [] row = {ID,maban_int,tenmon,dongia,soluong,status,time};
                nextModel.addRow(row);
                nextModel.fireTableDataChanged();
                
               
                dlogSuaDonHang.setVisible(false);
            }
           else{
               JOptionPane.showMessageDialog(null, "Nhập thiếu trường thông tin", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
           }
       
        } catch (NumberFormatException e) {
           JOptionPane.showMessageDialog(null, "Bạn nhập sai rồi", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
        }
    }//GEN-LAST:event_btnDonXacNhan1ActionPerformed

    private void btnHuyDon1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHuyDon1ActionPerformed
        dlogSuaDonHang.setVisible(false);
    }//GEN-LAST:event_btnHuyDon1ActionPerformed

    private void jButton8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton8MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton8MouseClicked

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        DefaultTableModel nextModel = (DefaultTableModel)jTable1.getModel();
            Ban new_ban = new Ban();
            String idString = labelBan.getText();
            String txtTT =  (txtChageBanStatuc.getSelectedItem()).toString();
            String txtLoai = txtChageType.getText();
            try{
                
                new_ban.setLoai_ban(txtLoai);
                new_ban.setMa(idString);
                
                new_ban.setTrang_thai(txtTT);
                if("Mới".equals(txtTT)){
                    stBan1.replace(Integer.parseInt(idString),1);
                }
                else{
                     stBan1.replace(Integer.parseInt(idString),1);
                }
                Object [] row = {idString,txtLoai,txtTT};
                nextModel.removeRow(select);
                nextModel.addRow(row);
                nextModel.fireTableDataChanged();
                
                dlogidChageBan.setVisible(false);
            }
            catch(IllegalArgumentException e ){
                showMess(e.getMessage());
               
            }

    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton9MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton9MouseClicked

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        // TODO add your handling code here:
        dlogidChageBan.setVisible(false);
    }//GEN-LAST:event_jButton9ActionPerformed

    private void txtLoaiBanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtLoaiBanActionPerformed
        
    }//GEN-LAST:event_txtLoaiBanActionPerformed

    private void jButton3MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton3MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton3MouseEntered

    

            
  static HashMap<Integer,Integer> phanquyen;
  static String[] col_don_hang = {" Mã ","Mã Bàn","Tên món","Đơn giá","Số lượng","Trạng thái","Thời gian"};
  static DefaultTableModel model_don_hang = new DefaultTableModel(col_don_hang,0);
  static String[] col = {"ID","Họ tên","Tuổi","Quê","Lương","Chức vụ"};
   static DefaultTableModel model_nhanvien = new DefaultTableModel(col,0);
   static int view = 1;
   static public HashSet<Integer> person;
   static public HashSet<Integer> banHashSet;
   static String tk;
   static String mk;
    public HashMap<String,String> login_HashMap;
    public int quyen;
    static String[] col_ban = {"Mã","Loại","Trạng thái"};
   static DefaultTableModel model_ban = new DefaultTableModel(col_ban,0);
   static int select = -1;
   static public HashMap<Integer,Integer> stBan1;
  
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCancel;
    private javax.swing.JButton btnDangNhap;
    private javax.swing.JButton btnDonXacNhan;
    private javax.swing.JButton btnDonXacNhan1;
    private javax.swing.JButton btnHuyDon;
    private javax.swing.JButton btnHuyDon1;
    private javax.swing.JButton btnOK;
    private javax.swing.JButton btnTimKiem;
    private javax.swing.JButton btnXacNhan;
    private javax.swing.JButton btnXoa;
    private javax.swing.JComboBox<String> cboChageChucVu;
    private javax.swing.JComboBox<String> cmbChucVU;
    private javax.swing.JDialog dlogBan;
    private javax.swing.JDialog dlogDoiMK;
    private javax.swing.JDialog dlogDonHang;
    private javax.swing.JDialog dlogLogin;
    private javax.swing.JDialog dlogSuaDonHang;
    private javax.swing.JDialog dlogSuaTen;
    private javax.swing.JDialog dlogidChageBan;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JDialog jDialog2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel labTen;
    private javax.swing.JLabel labThongBao;
    private javax.swing.JLabel labelBan;
    private javax.swing.JLabel labelChageDonHang;
    private javax.swing.JMenuItem mnBan;
    private javax.swing.JMenuItem mnDoiMK;
    private javax.swing.JMenuItem mnDonDat;
    private javax.swing.JMenu mnFile;
    private javax.swing.JMenuItem mnNhanVien;
    private javax.swing.JTextField txtAge;
    private javax.swing.JTextField txtBanIDDH;
    private javax.swing.JTextField txtBanId;
    private javax.swing.JComboBox<String> txtBanTT;
    private javax.swing.JTextField txtChageBanDonHang;
    private javax.swing.JComboBox<String> txtChageBanStatuc;
    private javax.swing.JTextField txtChageDonGia;
    private javax.swing.JLabel txtChageID;
    private javax.swing.JTextField txtChageLuong;
    private javax.swing.JTextField txtChageQue;
    private javax.swing.JTextField txtChageSoLuong;
    private javax.swing.JComboBox<String> txtChageStatus;
    private javax.swing.JTextField txtChageTen;
    private javax.swing.JTextField txtChageTenMon;
    private javax.swing.JTextField txtChageTuoi;
    private javax.swing.JTextField txtChageType;
    private javax.swing.JTextField txtDonGia;
    private javax.swing.JTextField txtHT;
    private javax.swing.JTextField txtID;
    private javax.swing.JTextField txtId;
    private javax.swing.JTextField txtLaiMKMoi;
    private javax.swing.JTextField txtLoaiBan;
    private javax.swing.JTextField txtLuong;
    private javax.swing.JTextField txtMKCU;
    private javax.swing.JTextField txtMKMoi;
    private javax.swing.JTextField txtMatKhau;
    private javax.swing.JTextField txtSoLuong;
    private javax.swing.JTextField txtTaiKhoan;
    private javax.swing.JTextField txtTen;
    private javax.swing.JTextField txtTenMon;
    private javax.swing.JTextField txtTimKiem;
    // End of variables declaration//GEN-END:variables
}
class ImagePanel extends JComponent {
    private Image image;
    public ImagePanel(Image image) {
        this.image = image;
    }
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(image, 0, 0, this);
    }
}

// elsewhere
