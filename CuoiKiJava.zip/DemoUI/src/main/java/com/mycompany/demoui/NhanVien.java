/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.demoui;

/**
 *
 * @author THINKPAD
 */
public class NhanVien {
    public String Hoten;
    public int tuoi;
    public String que;
    public double luong;
    public String chucvu;
    public int ID;
    public NhanVien(int ID,String Hoten, int tuoi, String que, double luong,String chucvu) {
        this.Hoten = Hoten;
        this.tuoi = tuoi;
        this.ID = ID;
        this.que = que;
        this.luong = luong;
        this.chucvu = chucvu;
    }
   
}
