/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.demoui;

/**
 *
 * @author THINKPAD
 */
public class DonDatHang {
    public int ma_don;

    public DonDatHang(int ma_don, String ten_mon, float don_gia, int so_luong, String status, String time) {
        this.ma_don = ma_don;
        this.ten_mon = ten_mon;
        this.don_gia = don_gia;
        this.so_luong = so_luong;
        this.status = status;
        this.time = time;
    }
    public String ten_mon;
    public float don_gia;
    public int so_luong;
    public String status;
    public String time;
    
    
}
