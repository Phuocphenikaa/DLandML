package com.mycompany.demoui;




/**
 *
 * @author THINKPAD
 */
public class Ban {
    public int ma;
    public String loai_ban;
    public String trang_thai;

    public void setMa(String ma) {
        if("".equals(ma)){
            throw new IllegalArgumentException("Ma khong duoc de trong");
        }
        int ma1 = Integer.parseInt(ma);
        if(ma1<0){
            throw new IllegalArgumentException("Ma khong duoc nho hon 0");
        }
        this.ma = ma1;
    }

    public void setLoai_ban(String loai_ban) {
        if("".equals(loai_ban)){
            throw new IllegalArgumentException("Loai ban khong duoc de trong");
        }
        this.loai_ban = loai_ban;
    }

    public void setTrang_thai(String trang_thai) {
        this.trang_thai = trang_thai;
    }
}
